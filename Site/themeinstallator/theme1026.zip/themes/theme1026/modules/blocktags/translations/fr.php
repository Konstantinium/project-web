<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocktags}prestashop>blocktags_f2568a62d4ac8d1d5b532556379772ba'] = 'Bloc mots-clés';
$_MODULE['<{blocktags}prestashop>blocktags_b2de1a21b938fcae9955206a4ca11a12'] = 'Ajoute un bloc contenant vos mots-clés de produit.';
$_MODULE['<{blocktags}prestashop>blocktags_b15e7271053fe9dd22d80db100179085'] = 'Ce module nécessite d\'être greffé sur une colonne, mais votre thème n\'a pas de colonne.';
$_MODULE['<{blocktags}prestashop>blocktags_8d731d453cacf8cff061df22a269b82b'] = 'Veuillez remplir le champ "Mots-clés affichés".';
$_MODULE['<{blocktags}prestashop>blocktags_73293a024e644165e9bf48f270af63a0'] = 'Nombre invalide.';
$_MODULE['<{blocktags}prestashop>blocktags_c888438d14855d7d96a2724ee9c306bd'] = 'Mise à jour réussie';
$_MODULE['<{blocktags}prestashop>blocktags_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blocktags}prestashop>blocktags_726cefc6088fc537bc5b18f333357724'] = 'Mots-clés affichés';
$_MODULE['<{blocktags}prestashop>blocktags_ac7203a881dd6a546c362b2e0ec180e5'] = 'Définissez le nombre de mots-clés que vous voudriez voir affichés dans ce bloc.';
$_MODULE['<{blocktags}prestashop>blocktags_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blocktags}prestashop>blocktags_189f63f277cd73395561651753563065'] = 'Mots-clés';
$_MODULE['<{blocktags}prestashop>blocktags_49fa2426b7903b3d4c89e2c1874d9346'] = 'En savoir plus sur';
$_MODULE['<{blocktags}prestashop>blocktags_4e6307cfde762f042d0de430e82ba854'] = 'Aucun mot-clé spécifié pour le moment.';
$_MODULE['<{blocktags}prestashop>blocktags_70d5e9f2bb7bcb17339709134ba3a2c6'] = 'Aucun mot-clé spécifié pour le moment';


return $_MODULE;
