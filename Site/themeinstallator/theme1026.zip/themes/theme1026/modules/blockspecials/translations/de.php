<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockspecials}prestashop>blockspecials_c19ed4ea98cbf319735f6d09bde6c757'] = 'Block Sonderangebote';
$_MODULE['<{blockspecials}prestashop>blockspecials_f5bae06098deb9298cb9ceca89171944'] = 'Fügt einen Block mit aktuellen Sonderangeboten hinzu';
$_MODULE['<{blockspecials}prestashop>blockspecials_b15e7271053fe9dd22d80db100179085'] = 'Das Modul kann nur an eine Spalte angedockt werden. Die gibt es aber in diesem Template nicht.';
$_MODULE['<{blockspecials}prestashop>blockspecials_c888438d14855d7d96a2724ee9c306bd'] = 'Einstellungen aktualisiert';
$_MODULE['<{blockspecials}prestashop>blockspecials_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blockspecials}prestashop>blockspecials_24ff4e4d39bb7811f6bdf0c189462272'] = 'Block immer anzeigen';
$_MODULE['<{blockspecials}prestashop>blockspecials_53d61d1ac0507b1bd8cd99db8d64fb19'] = 'Block anzeigen, auch wenn kein Produkt verfügbar ist.';
$_MODULE['<{blockspecials}prestashop>blockspecials_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktiviert';
$_MODULE['<{blockspecials}prestashop>blockspecials_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{blockspecials}prestashop>blockspecials_61465481ac2491b37e4517960bbd4a14'] = 'Anzahl der Cache-Dateien';
$_MODULE['<{blockspecials}prestashop>blockspecials_e80a11f1704b88ad50f8fc6ce0f43525'] = 'Sonderangebote werden nach Zufallsauswahl im Front Office angezeigt. Um dafür nicht zuviel Ressourcen zu binden, sollten die Ergebnisse gecacht werden. Der Cache-Speicher wird täglich aktualisiert. Eingabe von 0 deaktiviert das Caching.';
$_MODULE['<{blockspecials}prestashop>blockspecials_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{blockspecials}prestashop>blockspecials_d1aa22a3126f04664e0fe3f598994014'] = 'Sonderangebote';
$_MODULE['<{blockspecials}prestashop>blockspecials_b4f95c1ea534936cc60c6368c225f480'] = 'Alle Sonderangebote';
$_MODULE['<{blockspecials}prestashop>blockspecials_3c9f5a6dc6585f75042bd4242c020081'] = 'Aktuell keine Sonderangebote';


return $_MODULE;
