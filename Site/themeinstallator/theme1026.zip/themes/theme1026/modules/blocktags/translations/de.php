<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocktags}prestashop>blocktags_f2568a62d4ac8d1d5b532556379772ba'] = 'Block Tags';
$_MODULE['<{blocktags}prestashop>blocktags_b2de1a21b938fcae9955206a4ca11a12'] = 'Fügt einen Block mit einer Tag-Cloud hinzu';
$_MODULE['<{blocktags}prestashop>blocktags_b15e7271053fe9dd22d80db100179085'] = 'Das Modul kann nur an eine Spalte angedockt werden. Die gibt es aber in diesem Template nicht.';
$_MODULE['<{blocktags}prestashop>blocktags_8d731d453cacf8cff061df22a269b82b'] = 'Sie müssen das Feld "Angezeigte Tags" ausfüllen.';
$_MODULE['<{blocktags}prestashop>blocktags_73293a024e644165e9bf48f270af63a0'] = 'Ungültige Anzahl';
$_MODULE['<{blocktags}prestashop>blocktags_c888438d14855d7d96a2724ee9c306bd'] = 'Einstellungen aktualisiert';
$_MODULE['<{blocktags}prestashop>blocktags_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blocktags}prestashop>blocktags_726cefc6088fc537bc5b18f333357724'] = 'Angezeigte Tags';
$_MODULE['<{blocktags}prestashop>blocktags_ac7203a881dd6a546c362b2e0ec180e5'] = 'Anzahl der Tags festlegen, die in diesem Block angezeigt werden sollen.';
$_MODULE['<{blocktags}prestashop>blocktags_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{blocktags}prestashop>blocktags_189f63f277cd73395561651753563065'] = 'Tags';
$_MODULE['<{blocktags}prestashop>blocktags_49fa2426b7903b3d4c89e2c1874d9346'] = 'Mehr darüber';
$_MODULE['<{blocktags}prestashop>blocktags_4e6307cfde762f042d0de430e82ba854'] = 'noch keine Tags angegeben';
$_MODULE['<{blocktags}prestashop>blocktags_70d5e9f2bb7bcb17339709134ba3a2c6'] = 'noch keine Tags angegeben';


return $_MODULE;
