<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcontact}prestashop>blockcontact_df8f3e2cd8d1acbb2d1aa46a45045ec5'] = 'Contact block';
$_MODULE['<{blockcontact}prestashop>blockcontact_318ed85b9852475f24127167815e85d9'] = 'Allows you to add additional information about your store\'s customer service.';
$_MODULE['<{blockcontact}prestashop>blockcontact_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuration updated';
$_MODULE['<{blockcontact}prestashop>blockcontact_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{blockcontact}prestashop>blockcontact_7551cf1a985728fa2798db32c2ff7887'] = 'Telephone number';
$_MODULE['<{blockcontact}prestashop>blockcontact_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'Email';
$_MODULE['<{blockcontact}prestashop>blockcontact_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{blockcontact}prestashop>blockcontact_9cfc9b74983d504ec71db33967591249'] = 'Contact Us';
$_MODULE['<{blockcontact}prestashop>blockcontact_75858d311c84e7ba706b69bea5c71d36'] = 'Our support hotline is available 24/7.';
$_MODULE['<{blockcontact}prestashop>blockcontact_673ae02fffb72f0fe68a66f096a01347'] = 'Phone:';
$_MODULE['<{blockcontact}prestashop>blockcontact_736c5a7e834b7021bfa97180fc453115'] = 'Contact our expert support team!';
$_MODULE['<{blockcontact}prestashop>nav_9cfc9b74983d504ec71db33967591249'] = 'Contact Us';
$_MODULE['<{blockcontact}prestashop>nav_320abee94a07e976991e4df0d4afb319'] = 'Call us now:';
$_MODULE['<{blockcontact}prestashop>nav_02d4482d332e1aef3437cd61c9bcc624'] = 'Contact us';


return $_MODULE;
