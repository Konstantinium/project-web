<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{homeslider}prestashop>homeslider_693b83f5eca43e2bb1675287c37ce9e2'] = 'Diapositivas de imágenes para tu página web';
$_MODULE['<{homeslider}prestashop>homeslider_c17aed434289cedd02618451e12c8da6'] = 'Añade una diapositiva de imágenes a tu página principal.';
$_MODULE['<{homeslider}prestashop>homeslider_3f80dc2cdd06939d4f5514362067cd86'] = 'Valores no válidos';
$_MODULE['<{homeslider}prestashop>homeslider_a6abafe564d3940cc36ee43e2f09400b'] = 'Diapositiva no válido';
$_MODULE['<{homeslider}prestashop>homeslider_e0ce30bfbf90d2306ecf72f06a83133f'] = 'Estado no válido de diapositivas.';
$_MODULE['<{homeslider}prestashop>homeslider_9f79795e050649dc6b8bd0cdc874cbdc'] = 'Posición de la diapositiva no  válido.';
$_MODULE['<{homeslider}prestashop>homeslider_76ad3ac84a702b0497cd6be8e8886d34'] = 'id_slide no válido';
$_MODULE['<{homeslider}prestashop>homeslider_14f09fd0804a8f1cd0eb757125fc9c28'] = 'El título es demasiado largo';
$_MODULE['<{homeslider}prestashop>homeslider_dc89634d1d28cd4e055531e62047156b'] = 'El título es demasiado largo.';
$_MODULE['<{homeslider}prestashop>homeslider_4477f672766f6f255f760649af8bd92a'] = 'La URL es demasiado larga';
$_MODULE['<{homeslider}prestashop>homeslider_62239300ba982b06ab0f1aa7100ad297'] = 'Descripción es demasiado larga';
$_MODULE['<{homeslider}prestashop>homeslider_980f56796b8bf9d607283de9815fe217'] = 'Formato de URL no es correcta';
$_MODULE['<{homeslider}prestashop>homeslider_73133ce32267e8c7a854d15258eb17e0'] = 'Nombre de archivo no válido.';
$_MODULE['<{homeslider}prestashop>homeslider_349097dadf7e6b01dd2af601d54fd59a'] = 'El título no se encuentra';
$_MODULE['<{homeslider}prestashop>homeslider_a9af2809b02444b9470f97dc66ba57a2'] = 'El título no está establecido.';
$_MODULE['<{homeslider}prestashop>homeslider_0f059227d0a750ce652337d911879671'] = 'URL no se encuentra';
$_MODULE['<{homeslider}prestashop>homeslider_8cf45ba354f4725ec8a0d31164910895'] = 'La imagen no se especifico';
$_MODULE['<{homeslider}prestashop>homeslider_7f82c65d548588c8d5412463c182e450'] = 'La configuración no ha podido actualizar';
$_MODULE['<{homeslider}prestashop>homeslider_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuración actualizada';
$_MODULE['<{homeslider}prestashop>homeslider_7cc92687130ea12abb80556681538001'] = 'Se produjo un error durante la carga de imágenes.';
$_MODULE['<{homeslider}prestashop>homeslider_cdf841e01e10cae6355f72e6838808eb'] = 'El slide no se puede añadir';
$_MODULE['<{homeslider}prestashop>homeslider_eb28485b92fbf9201918698245ec6430'] = 'El slide no se puede actualizar';
$_MODULE['<{homeslider}prestashop>homeslider_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desactivado';
$_MODULE['<{homeslider}prestashop>homeslider_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activado';
$_MODULE['<{homeslider}prestashop>homeslider_55b75a0d59fc613fa2e572226266ff08'] = 'Información de la diapositiva';
$_MODULE['<{homeslider}prestashop>homeslider_792744786ed30c5623dd1cf0c16f4ffe'] = 'Seleccione un archivo';
$_MODULE['<{homeslider}prestashop>homeslider_b78a3223503896721cca1303f776159b'] = 'Tratamiento';
$_MODULE['<{homeslider}prestashop>homeslider_e6b391a8d2c4d45902a23a8b6585703d'] = 'URL';
$_MODULE['<{homeslider}prestashop>homeslider_272ba7d164aa836995be6319a698be84'] = 'Título';
$_MODULE['<{homeslider}prestashop>homeslider_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Descripción';
$_MODULE['<{homeslider}prestashop>homeslider_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Activar';
$_MODULE['<{homeslider}prestashop>homeslider_93cba07454f06a4a960172bbd6e2a435'] = 'Sí';
$_MODULE['<{homeslider}prestashop>homeslider_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{homeslider}prestashop>homeslider_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{homeslider}prestashop>homeslider_f4f70727dc34561dfde1a3c529b6205c'] = 'Ajustes';
$_MODULE['<{homeslider}prestashop>homeslider_477964da3b7a710156efc82fc4bc72e2'] = 'Ancho máximo';
$_MODULE['<{homeslider}prestashop>homeslider_44877c6aa8e93fa5a91c9361211464fb'] = 'Velocidad';
$_MODULE['<{homeslider}prestashop>homeslider_105b296a83f9c105355403f3332af50f'] = 'Pausa';
$_MODULE['<{homeslider}prestashop>homeslider_1e6a508c037fc42ef6155eeadbb80331'] = 'Reproducir automáticamente';
$_MODULE['<{homeslider}prestashop>form_92fbf0e5d97b8afd7e73126b52bdc4bb'] = 'Elegir un fichero';
$_MODULE['<{homeslider}prestashop>list_c82324ebbcea34f55627a897b37190e3'] = 'Lista de diapositivas';
$_MODULE['<{homeslider}prestashop>list_7dce122004969d56ae2e0245cb754d35'] = 'Modificar';
$_MODULE['<{homeslider}prestashop>list_f2a6c498fb90ee345d997f888fce3b18'] = 'Eliminar';


return $_MODULE;
