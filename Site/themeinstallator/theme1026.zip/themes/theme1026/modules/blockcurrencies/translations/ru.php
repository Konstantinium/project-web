<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcurrencies}prestashop>blockcurrencies_f7a31ae8f776597d4282bd3b1013f08b'] = 'Блок валют';
$_MODULE['<{blockcurrencies}prestashop>blockcurrencies_80ed40ee905b534ee85ce49a54380107'] = 'Добавляет блок для выбора валюты.';
$_MODULE['<{blockcurrencies}prestashop>blockcurrencies_386c339d37e737a436499d423a77df0c'] = 'Валюта';


return $_MODULE;
