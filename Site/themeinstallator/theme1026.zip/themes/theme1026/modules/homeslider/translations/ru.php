<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{homeslider}prestashop>homeslider_693b83f5eca43e2bb1675287c37ce9e2'] = 'Слайдшоу для Вашей домашней страницы';
$_MODULE['<{homeslider}prestashop>homeslider_c17aed434289cedd02618451e12c8da6'] = 'Добавляет слайдшоу на домашнюю страницу.';
$_MODULE['<{homeslider}prestashop>homeslider_3f80dc2cdd06939d4f5514362067cd86'] = 'Недопустимое значение';
$_MODULE['<{homeslider}prestashop>homeslider_a6abafe564d3940cc36ee43e2f09400b'] = 'Недопустимый слайд';
$_MODULE['<{homeslider}prestashop>homeslider_e0ce30bfbf90d2306ecf72f06a83133f'] = 'Недопустимое состояние слайда.';
$_MODULE['<{homeslider}prestashop>homeslider_9f79795e050649dc6b8bd0cdc874cbdc'] = 'Недопустимая позиция слайда.';
$_MODULE['<{homeslider}prestashop>homeslider_14f09fd0804a8f1cd0eb757125fc9c28'] = 'Заголовок слишком длинный';
$_MODULE['<{homeslider}prestashop>homeslider_dc89634d1d28cd4e055531e62047156b'] = 'Заголовок слишком длинный.';
$_MODULE['<{homeslider}prestashop>homeslider_4477f672766f6f255f760649af8bd92a'] = 'URL слишком длинный.';
$_MODULE['<{homeslider}prestashop>homeslider_62239300ba982b06ab0f1aa7100ad297'] = 'Описание слишком длинное';
$_MODULE['<{homeslider}prestashop>homeslider_980f56796b8bf9d607283de9815fe217'] = 'Формат URL не корректный.';
$_MODULE['<{homeslider}prestashop>homeslider_73133ce32267e8c7a854d15258eb17e0'] = 'Неверное имя файла.';
$_MODULE['<{homeslider}prestashop>homeslider_349097dadf7e6b01dd2af601d54fd59a'] = 'Заголовок не задан.';
$_MODULE['<{homeslider}prestashop>homeslider_a9af2809b02444b9470f97dc66ba57a2'] = 'Отсутствует заголовок.';
$_MODULE['<{homeslider}prestashop>homeslider_0f059227d0a750ce652337d911879671'] = 'URL не задан.';
$_MODULE['<{homeslider}prestashop>homeslider_8cf45ba354f4725ec8a0d31164910895'] = 'Изображение не установлено';
$_MODULE['<{homeslider}prestashop>homeslider_7f82c65d548588c8d5412463c182e450'] = 'Конфигурация не может быть обновлена';
$_MODULE['<{homeslider}prestashop>homeslider_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Конфигурация обновлена';
$_MODULE['<{homeslider}prestashop>homeslider_7cc92687130ea12abb80556681538001'] = 'При загрузке картинки произошла ошибка';
$_MODULE['<{homeslider}prestashop>homeslider_cdf841e01e10cae6355f72e6838808eb'] = 'Слайд не может быть добавлен';
$_MODULE['<{homeslider}prestashop>homeslider_eb28485b92fbf9201918698245ec6430'] = 'Слайд не может быть обновлен.';
$_MODULE['<{homeslider}prestashop>homeslider_b9f5c797ebbf55adccdd8539a65a0241'] = 'Выключено';
$_MODULE['<{homeslider}prestashop>homeslider_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Включено';
$_MODULE['<{homeslider}prestashop>homeslider_792744786ed30c5623dd1cf0c16f4ffe'] = 'Выберите файл';
$_MODULE['<{homeslider}prestashop>homeslider_b78a3223503896721cca1303f776159b'] = 'Формы обращения';
$_MODULE['<{homeslider}prestashop>homeslider_e6b391a8d2c4d45902a23a8b6585703d'] = 'URL';
$_MODULE['<{homeslider}prestashop>homeslider_272ba7d164aa836995be6319a698be84'] = 'Заголовок';
$_MODULE['<{homeslider}prestashop>homeslider_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Описание';
$_MODULE['<{homeslider}prestashop>homeslider_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Активен';
$_MODULE['<{homeslider}prestashop>homeslider_93cba07454f06a4a960172bbd6e2a435'] = 'Да';
$_MODULE['<{homeslider}prestashop>homeslider_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Нет';
$_MODULE['<{homeslider}prestashop>homeslider_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{homeslider}prestashop>homeslider_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{homeslider}prestashop>homeslider_44877c6aa8e93fa5a91c9361211464fb'] = 'Скорость';
$_MODULE['<{homeslider}prestashop>homeslider_105b296a83f9c105355403f3332af50f'] = 'Пауза';
$_MODULE['<{homeslider}prestashop>homeslider_1e6a508c037fc42ef6155eeadbb80331'] = 'Авто проигрывание';
$_MODULE['<{homeslider}prestashop>form_92fbf0e5d97b8afd7e73126b52bdc4bb'] = 'Выберите файл';
$_MODULE['<{homeslider}prestashop>list_c82324ebbcea34f55627a897b37190e3'] = 'Список слайдов';
$_MODULE['<{homeslider}prestashop>list_7dce122004969d56ae2e0245cb754d35'] = 'Редактировать';
$_MODULE['<{homeslider}prestashop>list_f2a6c498fb90ee345d997f888fce3b18'] = 'Удалить';


return $_MODULE;
