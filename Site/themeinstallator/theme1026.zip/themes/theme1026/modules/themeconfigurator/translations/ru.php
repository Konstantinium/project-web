<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_e92dabb4907f1957cabc469cca4deefc'] = 'Конфигуратор темы';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_cf8fdaf6e745133c90516eb9b74e31c3'] = 'Настройка основных элементов вашей темы.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_eedb7e9e8a884cb0a78a55528e8b8fab'] = 'Более 500 + PrestaShop премиум шаблонов! Просмотреть сейчас!';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_ec870aa68b135c4f3adc9a3a2731ddbc'] = 'Не удается удалить слайд.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_3ee0c881516fce384747e3107dbfc538'] = 'Неверный контент';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_dd2681ec1593dd537587be3389ee24d3'] = 'Произошла ошибка при сохранении данных.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_b9099a0a16c40efc8b73f548144d472f'] = 'Обновление прошло успешно.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_07b8c09e490f7afbdcfa9cd5bfcfd4a9'] = 'Во время загрузки картинки произошла ошибка.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_dccadfc1bf4714d72add6b2332505009'] = 'Новый элемент успешно добавлен.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_f1206f9fadc5ce41694f69129aecac26'] = 'Настроить';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Включено';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_b9f5c797ebbf55adccdd8539a65a0241'] = 'Выключено';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_4351cfebe4b61d8aa5efa1d020710005'] = 'См.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_058e1168dd26085fe8d317effdf70dc3'] = 'Только вы сможете видеть это в Фронт-Офисе - ваши посетители не увидят этот инструмент.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_6e3670bb5e3826106c5243b242cc52d9'] = 'Отображать ссылки на социальные аккаунты вашего магазина (Twitter, Facebook и т.д.)';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_6080ab31226b39af728c2d40fd57f0d0'] = 'Отображать блок Facebook на главной странице';
$_MODULE['<{themeconfigurator}prestashop>items_b9b371458ab7c314f88b81c553f6ce51'] = 'Хук';
$_MODULE['<{themeconfigurator}prestashop>items_7dce122004969d56ae2e0245cb754d35'] = 'Редактировать';
$_MODULE['<{themeconfigurator}prestashop>items_d3d2e617335f08df83599665eef8a418'] = 'Закрыть';
$_MODULE['<{themeconfigurator}prestashop>items_e8cf85cec621489ec026f7e06c67eb4e'] = 'Удалить элемент';
$_MODULE['<{themeconfigurator}prestashop>items_2faec1f9f8cc7f8f40d521c4dd574f49'] = 'Включить';
$_MODULE['<{themeconfigurator}prestashop>items_6fed80a8c8ded2f5e14a687e4a443abc'] = 'Ширина изображения';
$_MODULE['<{themeconfigurator}prestashop>items_d399848208da8b80a306af0fd62bb03f'] = 'пикселей';
$_MODULE['<{themeconfigurator}prestashop>items_2aa3aa9d021c7cfffb5afa08f52fbc51'] = 'Высота изображения';
$_MODULE['<{themeconfigurator}prestashop>items_ea4788705e6873b424c65e91c2846b19'] = 'Отменить';
$_MODULE['<{themeconfigurator}prestashop>items_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{themeconfigurator}prestashop>items_f453e0c33edd79653febd0b9bc8f09b3'] = 'Нет доступных элементов';
$_MODULE['<{themeconfigurator}prestashop>new_ff19c966036b4a0c7350b2fc7e2861c2'] = 'Добавить элемент';
$_MODULE['<{themeconfigurator}prestashop>new_4994a8ffeba4ac3140beb89e8d41f174'] = 'Язык';
$_MODULE['<{themeconfigurator}prestashop>new_b78a3223503896721cca1303f776159b'] = 'Формы обращения';
$_MODULE['<{themeconfigurator}prestashop>new_2c92d496fa8efe3d5b2b38c185f9b7f7'] = 'Использовать заголовок спереди';
$_MODULE['<{themeconfigurator}prestashop>new_b9b371458ab7c314f88b81c553f6ce51'] = 'Хук';
$_MODULE['<{themeconfigurator}prestashop>new_be53a0541a6d36f6ecb879fa2c584b08'] = 'Изображение';
$_MODULE['<{themeconfigurator}prestashop>new_6fed80a8c8ded2f5e14a687e4a443abc'] = 'Ширина изображения';
$_MODULE['<{themeconfigurator}prestashop>new_21de26caa6bcfc936378c4e45d235bd9'] = 'px';
$_MODULE['<{themeconfigurator}prestashop>new_2aa3aa9d021c7cfffb5afa08f52fbc51'] = 'Высота изображения';
$_MODULE['<{themeconfigurator}prestashop>new_e6b391a8d2c4d45902a23a8b6585703d'] = 'URL';
$_MODULE['<{themeconfigurator}prestashop>new_4c87eb073eb09f42281d7e67aeacb223'] = 'Целевой бланк';
$_MODULE['<{themeconfigurator}prestashop>new_4c4ad5fca2e7a3f74dbb1ced00381aa4'] = 'HTML';
$_MODULE['<{themeconfigurator}prestashop>new_ea4788705e6873b424c65e91c2846b19'] = 'Отменить';
$_MODULE['<{themeconfigurator}prestashop>new_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_f5a35b8e88be7f51ad3a3714a83df3a1'] = 'Инструмент настройки позволяет изменить цвета и шрифты в вашей теме.';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_c71534403c6e05ffbb8684ae96aac550'] = 'Только вы видите этот инструмент из-за авторизации в качестве администратора бэк-офиса; ваши посетители не видят панель конфигуратора.';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_45e035baf33a8e403766a606457f8b10'] = 'Цвет шаблона';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_194f5394ae2e9c74dc3c441b92862d1d'] = 'Шрифт';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_9a2c00f5f6df185a8d7d421ee70ccddf'] = 'Название шрифта';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_ea3aba27f515989b46d990e95a097818'] = 'Выбрать шрифт';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_526d688f37a86d3c3f27d0c5016eb71d'] = 'Сброс';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';


return $_MODULE;
