<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{favoriteproducts}prestashop>favoriteproducts_c249aeb21294d5e97598462b550e73eb'] = 'Produits favoris';
$_MODULE['<{favoriteproducts}prestashop>favoriteproducts_018770f4456d82ec755cd9d0180e4cce'] = 'Affiche une page avec les produits favoris de l\'utilisateur.';
$_MODULE['<{favoriteproducts}prestashop>favoriteproducts-account_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Mon compte';
$_MODULE['<{favoriteproducts}prestashop>favoriteproducts-account_e5090b68524b1bbfd7983bfa9500b7c9'] = 'Mes produits favoris';
$_MODULE['<{favoriteproducts}prestashop>favoriteproducts-account_44fd621c6504b8a5346946650682a842'] = 'Vous ne possédez pas de produit favoris pour le moment.';
$_MODULE['<{favoriteproducts}prestashop>favoriteproducts-account_6f16227b3e634872e87b0501948310b6'] = 'Retour à votre compte';
$_MODULE['<{favoriteproducts}prestashop>favoriteproducts-extra_8128d66be9351da562f9b01f591e00cd'] = 'Ajouter ce produit à mes favoris';
$_MODULE['<{favoriteproducts}prestashop>favoriteproducts-extra_b895a379bd5ea51680ead24ee13a1bb7'] = 'Retirer ce produit de mes favoris';
$_MODULE['<{favoriteproducts}prestashop>my-account_e5090b68524b1bbfd7983bfa9500b7c9'] = 'Mes produits favoris';
$_MODULE['<{favoriteproducts}prestashop>favoriteproducts-account_a34e0796b9c15d09300f67d972379722'] = 'Mes produits favoris';
$_MODULE['<{favoriteproducts}prestashop>favoriteproducts-account_a958dbb46713e59856c35f89e5092a5e'] = 'Retour à votre compte';
$_MODULE['<{favoriteproducts}prestashop>my-account_a34e0796b9c15d09300f67d972379722'] = 'Mes produits favoris';


return $_MODULE;
